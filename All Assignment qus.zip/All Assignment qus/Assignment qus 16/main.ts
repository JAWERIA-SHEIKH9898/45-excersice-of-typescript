
// 16. More Guests: You just found a bigger dinner table, so now more space is available. Think of three more guests to invite to dinner.
// • Start with your program from Exercise 15. Add a print statement to the end of your program informing people that you found a bigger dinner table.

// • Add one new guest to the beginning of your array.

// • Add one new guest to the middle of your array. • Use append() to add one new guest to the end of your list. • Print a new set of invitation messages, one for each person in your list.


let Guest :string[] = ["aizal","warda"]
let message:string = ("I found a big dinner table")
console.log(`${message} ${Guest[0]}`)
console.log(`${message} ${Guest[1]}`)

// now i have more space is available.think of three more guest invite to dinner....
let MoreGuest :string[] = ["aizal","warda"]
// add more three guest...
MoreGuest.push("jiya","zuhaa","wayna")
let message2 :string = ("I have more space so i invited to dinner three more guests")
console.log(MoreGuest)
console.log(`${message2} ${MoreGuest[0]}`)
console.log(`${message2} ${MoreGuest[1]}`)
console.log(`${message2} ${MoreGuest[2]}`)
console.log(`${message2} ${MoreGuest[3]}`)
console.log(`${message2} ${MoreGuest[4]}`)


let NewGuest :string[] = ["aizal","warda","jiya","zuhaa","wayna"]
// add one new guest to the biginning of your array...
NewGuest.unshift("maria")
// add two new guest in the middle of my array...
NewGuest.splice( 2,3,"manahil","mubashira")
// add one new guest to the end of my array.....
NewGuest.push("warda")
console.log(NewGuest)
// print a new set of invitation messages,one for each person in your list....

console.log(` Dear!${NewGuest[5]},"Today i invited to you i found a big dinner table"`)





// let InviteMessage :string =("Today i invited to you beacuse i found a big dinner table ")

// console.log(` Dear!${NewGuest[1]},"Today i invited to you i found a big dinner table"`)
// console.log(` Dear!${NewGuest[2]},"Today i invited to you i found a big dinner table"`)
// console.log(` Dear!${NewGuest[3]},"Today i invited to you i found a big dinner table"`)
// console.log(` Dear!${NewGuest[4]},"Today i invited to you i found a big dinner table"`)
// console.log(` Dear!${NewGuest[5]},"Today i invited to you i found a big dinner table"`)











