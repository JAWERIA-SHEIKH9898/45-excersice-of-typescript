// 1.Install[Node.js](http://nodejs.org/en/),[Typescript](https://www.typescriptlang.org/download)and[VS Code](https://code.visualstudio.com/)on your computer
// Ans...
// All material are intalled in my computer
// 2. Personal message: store a person's name in a variables, and print a message to that person. Your message should be simple,such as, "Hello Eric, would you like to learn some python today?"
// Ans....
var firstname = "Hello Eric";
console.log("\"Hello ".concat(firstname, " would you like to learn some python today?\""));
