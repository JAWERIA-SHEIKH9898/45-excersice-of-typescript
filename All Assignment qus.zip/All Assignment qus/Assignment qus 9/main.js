// 9.Names: Store the names of a few of your friends in a array called names. Print each person’s name by accessing each element in the list, one at a time.
// Ans...
// Store names in an array
var Girls = ["jiya", "wayna", "zuhaa", "mubashira", "sobia"];
// Print each person's name by accessing each element in the array
console.log(Girls[0]);
console.log(Girls[1]);
console.log(Girls[2]);
console.log(Girls[3]);
console.log(Girls[4]);
