// 7.Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message..
// Ans...
var favoriteNumber = 5;
var message1 = " My lucky number is ";
console.log(" ".concat(message1, " ").concat(favoriteNumber));
