// 6.Stripping Names: Store a person's name ,and include some whitespace characters at the biginning and end of the name. Make sure you you use each..
// character combination, "\t" and "\n",st least once.print the name once ,so the whitespace around the name is displayed.Then print the name after striping the white spaces...

// Ans...
console.log("HelloDearFriend")
console.log("Hello\tDear\tFriend")
console.log("Hello\nDear\nFriend")
// console.log("You\nAre\nMy\nTrueFriend")